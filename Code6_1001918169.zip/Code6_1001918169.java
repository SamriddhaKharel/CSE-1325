/*
 * Samriddha Kharel 1001918169
 */
package code6_1001918169;

/**
 *
 * @author samdm
 */
import javax.swing.JFrame;

public class Code6_1001918169
{

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args)
    {
        Password password = new Password();
        password.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        password.setSize (650,380);
        password.setVisible(true);      

    }
    
}
