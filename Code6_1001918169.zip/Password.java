/*
 * Samriddha Kharel 1001918169
 */
package code6_1001918169;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
/**
 *
 * @author samdm
 */

public class Password extends JFrame
{

    private final JTextField textField1;

    private final JPasswordField passwordField;
    final String actualPassword = "abcd";
    String userPassword ;
    
    public Password()
    {
        super("Enter the password to continue..."); 
        setLayout (new FlowLayout());
        textField1= new JPasswordField(10);
   

        passwordField = new JPasswordField(10); 
        passwordField.setEchoChar('X');
     
        add(passwordField);
        EventHandler handler = new EventHandler();
        textField1.addActionListener(handler);
     
        passwordField.addActionListener(handler);
    }
    
    
    private class EventHandler implements ActionListener
    {
        
        @Override
        
        public void actionPerformed(ActionEvent event)
        {
            GameFrame gameFrame = new GameFrame();
            gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            gameFrame.setSize(1300,800);
            

            String string = "";
            if (event.getSource() == passwordField)      
            {
                userPassword = event.getActionCommand();  
            }
         
            if (userPassword.equals(actualPassword))
            {
                System.out.println("login succesful");
                setVisible(false);       
                gameFrame.setVisible(true);
            } 
            if (userPassword.equals(actualPassword) == false)
            {
                System.out.println("incorrect");
                string = String.format("Invalid password...please try again ");
                JOptionPane.showMessageDialog(null, string);
            }
        }
    }  


   
}
